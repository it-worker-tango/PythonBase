def hello(name):
    print("{}你好!".format(name))

def sayBye(name):
    pass #空语句，什么都不做

myname = 'Tango'
hello(myname) #调用函数