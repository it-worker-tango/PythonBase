def sum(a, b):
    '''计算a的b次方，并返回'''
    return a**b

print('{}的{}次方是{}'.format(2, 2, sum(2, 2)))
print('{}的{}次方是{}'.format(2, 3, sum(2, 3)))