def msg():
    message = "你好"
    print("局部变量的内容:", message)

msg()
print("messaged的内容", message)