with open('demo.txt', 'w') as file:
    file.write("abcdefghijklmn") # 将"abcdefghijklmn"写入文件，并覆盖掉原来的内容
print("文件操作结束")