with open("msg.txt", 'r', encoding='utf-8') as file:
   msg = file.readlines()
   print(msg)